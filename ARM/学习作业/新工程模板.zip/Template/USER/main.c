#include "stm32f10x.h"
#include <stdio.h>

int main(void)
{
 
  while (1)
  {
  }
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
